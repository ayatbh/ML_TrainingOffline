import numpy as np
import Run_tflite

def MaxClass(x) :
    m = x[0]
    pos = 0
    for i in range(len(x)):
        if x[i]>m:
            m = x[i]
            pos = i
    return pos



X = np.load('.\\X_val.npy')
class_predictions = []

for data in X:
    prediction = Run_tflite.test_datum(data)
    class_p = MaxClass(prediction[0])
    class_predictions.append(class_p)

for i in range(125):
    print(class_predictions[i])

#print(class_predictions)
#print(len(class_predictions))